jQuery.widget( 'gc.passwordField', $.gc.stringField, {
	getInputType: function() {
		return "password";
	}

} );