(function($, undefined){
	$.fn.datepickerJQ = $.fn.datepicker;
}(window.jQuery));